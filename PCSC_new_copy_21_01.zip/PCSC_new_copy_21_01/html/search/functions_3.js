var searchData=
[
  ['histogram_17',['histogram',['../classImageClass.html#a780daba07a4f78fbdfbca932d5c3e600',1,'ImageClass']]]
];
