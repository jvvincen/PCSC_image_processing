var searchData=
[
  ['get_5fintensity_13',['get_intensity',['../classImageClass.html#ae1e610f5b8eb09af8975ebd2a5f0edd6',1,'ImageClass']]],
  ['get_5fncol_14',['get_ncol',['../classImageClass.html#ae358ccd8c58b1d20776de8a37196d0b9',1,'ImageClass']]],
  ['get_5fnrows_15',['get_nrows',['../classImageClass.html#a6fbc5f9e9cdbe46c6e6d7dc3f904b56b',1,'ImageClass']]],
  ['get_5fpixels_16',['get_pixels',['../classImageClass.html#a32f99a306e9e7d30245e568142fe018b',1,'ImageClass']]]
];
