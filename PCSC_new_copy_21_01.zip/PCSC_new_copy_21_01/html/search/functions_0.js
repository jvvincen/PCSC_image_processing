var searchData=
[
  ['convolve_11',['convolve',['../classImageClass.html#a2cf7d21b37b1fc5952232da34e0c6f7f',1,'ImageClass']]]
];
